TYPO3: Unix Archives
******************************************

In these directories you find 'Unix-optimized' archives of TYPO3

The contents of these directories are as follows:

SITES
==========

dummy:      The "Dummy" site
            Use this if you want to start to start with a blank site.

quickstart: The "Quickstart" site
            Use this in combination with the lecture of the Quickstart
            document that can be found on http://typo3.org/

testsite:   The "Testsite" package contains a set of examples you can use
            for your own site. Use this in combination with the "Typoscript
            by example" document.


SOURCE
==========
typo3_src:  This is probably the most important file. It contains the
            source of TYPO3. You will always need this to get started with
            your site. Combined with one of the site archives (above) this
            is what people call the 'website'.

You can find a backup of the previous version set in the ../3.5.0/ folder.

(The Freesite package is no more available. Was there anybody using it?!)

-- Michael Stucki <mundaun@gmx.ch>  Sat,  01 May 2004 16:53:18 +0100
