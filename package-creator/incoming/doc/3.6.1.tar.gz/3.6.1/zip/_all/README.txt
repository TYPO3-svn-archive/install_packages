************************************
* README.TXT                       *
* Thank you for downloading Typo3! *
* Please read this before you do   *
* anything else!                   *
*                                  *
************************************

1. About this package
******************************************
Please note that you have downloaded the "newbie package". If you are an experienced Unix 
user you might wish to download the "clean" .tgz release with updated core files only, and 
add either the test site or dummy (empty) database structure as required.

This package contains a fully functional test site with lots of examples and information. 
It also has the rich text editor extension pre-installed. This document contains a short 
summary of what Typo3 is about, along with some pointers to further information - please 
read the docs carefully before you ask questions on the mailinglist.


2. What is Typo3?
*******************************************
Typo3 is developed by the Danish programmer Kasper Skaarhoej. It is the most advanced GPL 
Content Management Framework available, and competes very successfully with commercial 
products costing $50.000. Typo3 is distributed under the GPL license, however Kasper 
has expressed certain aims for the system which we ask you to respect (see typo3.com 
for more information). 

To get more info about the GPL license, visit http://www.opensource.org/licenses/gpl-license.php.


3. What Typo3 is not?
*******************************************
Typo3 is not a portalpage toolset like PHPNUKE, or bulletin board like PHPBB2...it is 
not designed to offer one specific function. If you have a defined requirement, a 
product designed to address that need may be a better choice. Typo3 offers a huge toolbox
for developing and managing your web site, with many built-in features, and more available
for installation, but is not a readymade solution to cover all needs.


4. What is a Content Management Framework?
*******************************************
A CM Framework means is more than just a content management system, because of the separation
of the streamlined core, and optional plugins (extensions). Typo3 has an open API that 
allows you to extend the frontend (web site) and/or backend (administration) functionalities. 
This concept of extension makes Typo3 capable of being developed in almost any way you can 
imagine, either by using any of the many extensions already available, or writing your own.


5. The Typo3 core requirements
*******************************************
Typo3 is based upon PHP4, and uses a mySQL3/4 database. If you want to use the graphics 
functions (which are highly recommended) you will need the php gdLib extension, and the 
serverside image processing program ImageMagick (that is available for both Unix/Linux & 
Windows). For more information regarding these requirements see the INSTALL.TXT file in this
folder.


6. What should you do if you have a problem?
*******************************************
Typo3 is a powerful and complex professional application. When you start out there will be 
many things you simply don�t understand, or that don't seem to make sense. There is a 
widely used mailinglist (see resources below) where many experienced users and developers 
lurk...they are always willing to help, provided you followed these steps BEFORE you ask 
the list:

  1. read all available documentation carefully
  2. read all available documentation carefully again
  3. search the mailinglist archive carefully
  4. if you still can�t figure out - ask the list, see guidelines below
     4a. be polite
     4b. always include the version of used Typo3 and server environmnent (phpinfo())
     4c. be as specific as possible - questions like "my Typo3 installation does not 
     work - what can i do???" will be ignored. Although English may not be your first 
     language, if those reading your post don't understand it, you won't get the help 
     you need
     4d. if you are really having a tough time getting something working, stay cool and
     don't criticise or flame. Problems are normally caused by lack of research into the
     documentation, or misunderstanding, not because of bugs. Be logical about your 
     troubleshooting, and you'll get there
  5. if you have identified a genuine new bug report it to bugs@typo3.com do not post
     to the list about it


7. How to get started
*******************************************
Please see the INSTALL.TXT in this folder. Once you have succeeded with installing the 
test site you should proceed to the "first-steps" folder which contains tutorials covering
the most basic actions in Typo3. This should get you started very quickly. 

Once you've succeeded in creating some basic pages and templates, you'll want to do some 
more advanced stuff. You'll then need to learn some TypoScript. This is the scripting/definition
"language" developed by Kasper, that is the powerhouse at the heart of TypoScript. It is used 
to define the parameters within the page templates. A good starting point is the document 
TypoScript by Example, where the basic concepts are explained and demonstrated, followed by 
the main reference document, the TSref (see also below).

Good luck.


8. Typo3 resources
*******************************************
http://www.google.com/search?q=typo3 - no just kidding, here is an overview of the most 
important Typo3 ressources that should be checked first.

  www.typo3.com
  ********************
  Homepage of Typo3. 
  Here you find related Typo3 related links as well as more general overview of Typo3

  typo3.org
  ********************
  Typo3 Community/Projects related platform. 
  This is the place to go for Typo3 developers and admins, mailing list archives etc.

  typo3.toaster-schwerin.de
  *************************
  The (old) Typo3 mailinglist archive.
  There is another one at Typo3.org http://typo3.org/index.php?id=1422

  Documentation
  *************
  Typo3 is once of the most thoroughly documented OpenSource products around, with manuals 
  covering basic tutorials, TypoScript, administration, development, core structure, etc. 
  You should make the time to locate the various documents, and read those that apply to 
  the work you want to do. You'll find most of the questions you may need to ask will be 
  answered somewhere. The documentation is available from typo3.org.

  Some German documentations are listed at http://freeweb.dnet.it/typo3/

9. Some final notes
********************************************
Typo3 is said to be one of the most sophisticated PHP/internet related applications available,
and the more you play with it the more you will agree. Due to the advanced level of the code 
and functionality, a degree of study, time and perseverance is required to fully understand 
it, and get the best from it - but keep trying, it's definetly worth it. Typo3 is the 
ultimate CMF "for all". 

The GPL license allows for developments that are based upon Typo3 to also be freely available
under the GPL. Please remember this, because it is actually what Typo3 is about...it is 
a gift for us all to use and benefit from, but where our developments are given back to 
the community. If you are making money with Typo3 you are asked to donate to Kasper Skaarhoej
who is developing Typo3 on a full time basis, and making money only due to the support of the
growing community. See details on Typo3.com.


*******************************************************
* This document was last updated on December, 29 2003 *
*******************************************************