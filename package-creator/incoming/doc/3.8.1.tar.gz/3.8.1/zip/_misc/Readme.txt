All ZIP packages contain duplicated folders, in order to make them
work on Windows systems as well, which don't support symlinks.

Which folders and files are duplicated is written here:
http://typo3.org/doc.0.html?&tx_extrepmgm_pi1[extUid]=265&tx_extrepmgm_pi1[tocEl]=69&cHash=51b9e8280d#oodoc_part_73

-- Michael Stucki <michael@typo3.org>  Fri,  01 Apr 2005  08:04:25 +0200
