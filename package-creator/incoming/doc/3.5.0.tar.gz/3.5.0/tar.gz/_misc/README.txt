TYPO3: Unix Archives
******************************************

In this directory you find 'Unix-optimized' archives of TYPO3

Each directory contains archives in both tar.gz and tar.bz2 format. They
should always be in synch - just compare their version number!

The contents of these directories are as follows:

SITES
==========

Dummy:      The "Dummy" site
            Use this if you want to start to start with a blank site.

Freesite:   The "Freesite" package allows you to quickly set up new
            websites based on TYPO3s standard templates and with a new
            backend user automatically created (including home directory,
            correct page permissions etc.) thus forming a framework by
            which you can serve a lot of people a lot of (standard)
            websites from the same system in no time.

Quickstart: The "Quickstart" site
            Use this in combination with the lecture of the Quickstart
            document that can be found on http://typo3.org/

Testsite:   The "Testsite" package contains a set of examples you can use
            for your own site. Use this in combination with the "Typoscript
            by example" document.


SOURCE
==========
Typo3_src:  This is probably the most important file. It contains the
            source of TYPO3. You will always need this to get started with
            your site. Combined with one of the site archives (above) this
            is what people call the 'website'.

You can find a backup of the previous version set (only the tar.gz version)
in the _bak folder.

-- Michael Stucki <mundaun@gmx.ch>  Thu,  24 Jul 2003 19:18:52 +0200
