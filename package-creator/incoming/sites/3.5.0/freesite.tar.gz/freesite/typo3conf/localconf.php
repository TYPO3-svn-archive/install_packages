<?php

$TYPO3_CONF_VARS["BE"]["installToolPassword"] = "bacb98acf97e0b6112b1d1b650b84971";
$TYPO3_CONF_VARS["SYS"]["recursiveDomainSearch"]=1;
$TYPO3_CONF_VARS["FE"]["noPHPscriptInclude"] = 1;
$TYPO3_CONF_VARS["EXT"]["extConf"]["freesite"] = 'a:11:{s:11:"backendOnly";s:1:"1";s:19:"create_lockToDomain";s:1:"0";s:17:"createVirtualDirs";s:1:"0";s:17:"createNewGroupDir";s:1:"1";s:16:"createNewUserDir";s:1:"1";s:19:"pid_templateArchive";s:1:"2";s:21:"pid_dummyPagesArchive";s:1:"3";s:11:"pid_newsite";s:1:"1";s:17:"uid_templateGroup";s:1:"2";s:16:"uid_generalGroup";s:1:"0";s:12:"notify_email";s:0:"";}';
$TYPO3_CONF_VARS["EXT"]["extList"].= ',freesite';
$TYPO3_CONF_VARS["SYS"]["sitename"] = "Freesite";

$TYPO3_CONF_VARS["BE"]["lockRootPath"] ="/home/httpd/typo3_upload/freesite/";
$TYPO3_CONF_VARS["BE"]["userHomePath"] ="/home/httpd/typo3_upload/freesite/users/";
$TYPO3_CONF_VARS["BE"]["groupHomePath"] ="/home/httpd/typo3_upload/freesite/groups/";

?>
