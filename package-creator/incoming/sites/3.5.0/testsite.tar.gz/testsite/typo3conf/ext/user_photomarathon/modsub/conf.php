<?php

	// Relative path to the module from the typo3/ folder
define("TYPO3_MOD_PATH","../typo3conf/ext/user_photomarathon/modsub/");		
	// Relative path to the typo3/ folder
$BACK_PATH="../../../../typo3/";					

	// Module name as shown in the backend:
$MLANG["default"]["tabs"]["tab"] = "Photo Marathon";
	// Icon-file used with the module. Max 12 pixels high.
$MLANG["default"]["tabs_images"]["tab"] = "tab_icon.gif";
	// Short description for the tab image label:
$MLANG["default"]["labels"]["tablabel"] = "Photo Marathon (EXAMPLE!)";
	// Longer description, used in the "Help>About modules" module 
$MLANG["default"]["labels"]["tabdescr"] = "This is an example module related to the Photo Marathon part of the testsite. It's made to provide you with a framework for creating your own backend modules. Please dive into the php-scripts in typo3conf/web/uphotomarathon/*";


	// Danish translation of labels:
$MLANG["dk"]["tabs"]["tab"] = "Fotomaraton";
$MLANG["dk"]["labels"]["tablabel"] = "Fotomaraton (Eksempelmodul)";


	// Main script invoked:
$MCONF["script"]="index.php";		
	// Access level.
	// You can specify access for both backend users and groups to this module.
$MCONF["access"]="user,group";		

	// Syntax: [module]_[subModule]  or just [module] if no submodule!! 
	// Remember, never use underscore "_" in module names!
$MCONF["name"]="web_uphotomarathon";		

?>
