<?php

########################################################################
# Extension Manager/Repository config file for ext: 'user_photomarathon'
# 
# Auto generated 25-06-2002 16:34
# 
# Manual updates:
# Only the data in the array - anything else is removed by next write
########################################################################

$EM_CONF[$_EXTKEY] = Array (
	"title" => "Photo Marathon (plugin and module)",
	"description" => "Photo Marathon allows users to register, login and upload images in categories. Images must be approved by an admin first. Example of a plugin with a backend module and a frontend plugin.",
	"category" => "example",
	"shy" => 0,
	"dependencies" => "cms",
	"priority" => "",
	"module" => "modsub",
	"state" => "stable",
	"internal" => 0,
	"clearCacheOnLoad" => 1,
	"author" => "Kasper Sk�rh�j",
	"author_email" => "kasper@typo3.com",
	"author_company" => "Curby Soft Multimedia",
	"_md5_values_when_last_written" => "a:11:{s:12:\"ext_icon.gif\";s:4:\"9c4b\";s:14:\"ext_tables.php\";s:4:\"763c\";s:14:\"ext_tables.sql\";s:4:\"1d2c\";s:26:\"res/extTables_descr.dk.php\";s:4:\"5f06\";s:23:\"res/extTables_descr.php\";s:4:\"5acd\";s:30:\"res/tbl_user_photomarathon.php\";s:4:\"54c6\";s:16:\"modsub/clear.gif\";s:4:\"cc11\";s:15:\"modsub/conf.php\";s:4:\"8cdb\";s:16:\"modsub/index.php\";s:4:\"b27c\";s:20:\"modsub/locallang.php\";s:4:\"95c7\";s:19:\"modsub/tab_icon.gif\";s:4:\"9c4b\";}",
	"version" => "0.0.0",	// Don't modify this! Managed automatically during upload to repository.
);

?>