<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2001 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Help Descriptions for Photo Marathon records.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
 

$TCA_DESCR["user_photomarathon"] = Array (
	"columns" => Array (	
		"title" => Array(
			"description"=> "Enter the title of the image.",
			"details" => "This is displayed in the headers on the webpages.",
//			"image" => "../typo3conf/web/uphotomarathon/someImage.gif",
//			"image_descr" => "Here you see the title",
			"seeAlso" =>"user_photomarathon:description,user_photomarathon:images"
		),
		"description" => Array(
			"description"=>"Users may enter a description. This is shown with the image."
		),
		"images" => Array(
			"description"=>"The image. Users may upload up to 2 images."
		),
		"photodate" => Array(
			"description"=>"The date of the photo"
		),
		"fe_cruser_id" => Array(
			"description"=>"This field contains a reference to the fe_user (website user) who owns it. You should not change this. If you remove the user, the image will no longer belong to him and he cannot edit the image. In addition if you simply insert another user, the image will belong to this new user from that point in time."
		)
	)
);


?>