<?php


// Cache?:
// Typo3 caches pages by default. That means the content of your php-script is cached with everything else and thus your script is NOT executed next time you hit the page.
// Please notice that if you make a syntax error in your script, using set_no_cache() will NOT disable the page-cache and you must manually clear the cache from the backend and try again (after your script-bug is corrected that is... :-). Just keep it in mind...
// In order to disable caching, uncomment this line:


// set_no_cache();


if (is_object($this))	{
	$content.="<h3>The script element</h3>";
	$content.="Hi. You must enter 'code1' or 'code2' in the CODE field of the SCRIPT content element. <BR>Good luck.";

} else {
	die ("This script must be included by TypoScript");
}


?>
