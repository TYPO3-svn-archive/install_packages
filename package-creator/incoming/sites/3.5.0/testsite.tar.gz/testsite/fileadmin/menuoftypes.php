<?php

if (is_object($this))	{
	$types = $GLOBALS["TSFE"]->tmpl->setup["types."];
	$outArr=array();
	if (is_array($types))	{
		reset($types);
		while(list($k,$v)=each($types))	{
			$v=$GLOBALS["TSFE"]->type==$k ? '<b>'.$v.'</b>' : $v;
			$outArr[] = '<a href="index.php?id='.$GLOBALS["TSFE"]->id.'&type='.$k.'">'.$v.'</a>';
		}
	}
	$content = implode(" - ",$outArr)."<HR>";
}

?>
