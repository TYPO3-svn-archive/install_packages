<?php

include("typo3conf/localconf.php");
mysql_pconnect($typo_db_host,$typo_db_username,$typo_db_password);
$page_id = isset($HTTP_GET_VARS["id"]) ? $HTTP_GET_VARS["id"] : 0;
$res = mysql($typo_db,"SELECT * FROM pages WHERE uid=".intval($page_id)." AND NOT deleted");
if ($page_row = mysql_fetch_assoc($res))	{
	echo "<H2>".$page_row["title"]."</H2>";
	
	$res = mysql($typo_db,"SELECT * FROM tt_content WHERE pid=".intval($page_id)." AND NOT deleted ORDER BY sorting");
	while ($content_element_row = mysql_fetch_assoc($res))	{
		echo '<font size=2 face=verdana><strong>'.$content_element_row["header"].'</strong></font><BR>'.
			'<font size=1 face=verdana>'.nl2br($content_element_row["bodytext"]).'</font><BR><BR>';
	}
}

?>