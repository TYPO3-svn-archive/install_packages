<?php

class user_test_library_class {
	var $cObj;	// reference to the calling object.
	
	function test($content,$conf)	{
		global $TSFE;
		$TSFE->set_no_cache();	// Turning caching off - good while developing.
	
			// Query to select pages for the menu
		$query = "SELECT uid,title FROM pages 
			WHERE pid=".intval($TSFE->id).	// Subpages to current page
			$this->cObj->enableFields("pages").	// Include conditions for enableFields
			" ORDER by sorting";	// Sort by the sorting field so the order is correct
		// debug($query);
		$res = mysql(TYPO3_db,$query);	// Performing query
		$menuItems=array();		// Collect each element in this array
		while($row=mysql_fetch_assoc($res))	{
			$menuItems[]='<a href="?id='.$row["uid"].'">'.htmlspecialchars($row["title"]).'</a>';
		}
			// Imploding the elements into the output string:
		$outputString = implode("<BR>",$menuItems);
	
			// If set, add the font-tag parameters to this associative array:
		$fontTagParams = array();
		if ($conf["fontStyle."]["color"]) $fontTagParams["color"]=$conf["fontStyle."]["color"];
		if ($conf["fontStyle."]["face"]) $fontTagParams["face"]=$conf["fontStyle."]["face"];

			// If any font-tag parameters was set, wrap the output string:
		if (count($fontTagParams))	{
				// Compile array to attribute string
			$fontTagAttributes = t3lib_div::implodeParams($fontTagParams);	
			$outputString = '<font '.$fontTagAttributes.'>'.$outputString.'</font>';
		}
		
			// If border is enabled:
		if ($conf["border"])	{
			$outputString = 
				'<table border=1 bordercolor="'.
					($conf["border."]["color"]?$conf["border."]["color"]:"teal").
					'"><tr><td>'.
				$outputString.
				'</td></tr></table>';
		}
		return $outputString;
	}
}

?>