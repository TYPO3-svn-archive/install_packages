<?php

class user_test_library_class {
	var $cObj;	// reference to the calling object.
	
	function test($content,$conf)	{
		global $TSFE;
		$TSFE->set_no_cache();	// Turning caching off - good while developing.

			// Setting the path of files attached for page records, media field
		$imagePath = "uploads/media/";

			// exploding the list of files from the page record into this array
		$imageFilesArray = explode(",",$this->cObj->data["media"]);

		
		$accum=array();	// Collecting the image code in this array
		reset($imageFilesArray);
		while(list(,$theImage)=each($imageFilesArray))	{	// traverse the image list
				// Setting the file name, overriding ??? from TS:
			$conf["a_content_object."]["file"] = $imagePath.$theImage;
				
				// Getting the content object:
			$accum[] = $this->cObj->cObjGetSingle(
				$conf["a_content_object"],	// Contains the name, here "TEXT"
				$conf["a_content_object."],	// Contains the properties of "TEXT"
				"a_content_object"	// Basically just information for the TypoScript debugger
			);
		}

			// implode the files produced separated by a horizontal ruler		
		$outputString = implode("<HR>",$accum);

		return $outputString;
	}
}

?>