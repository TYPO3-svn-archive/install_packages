<?php

class user_test_library_class {
	var $cObj;	// reference to the calling object.
	
	function test($content,$conf)	{
		global $TSFE;
		$TSFE->set_no_cache();	// Turning caching off - good while developing.
		
		$conf["a_content_object."]["value"] = "The page title is: ".$TSFE->page["title"];
		$conf["a_content_object."]["case"] = "lower";
	
		$outputString = $this->cObj->cObjGetSingle(
			$conf["a_content_object"],	// Contains the name, here "TEXT"
			$conf["a_content_object."],	// Contains the properties of "TEXT"
			"a_content_object"	// Basically just information for the TypoScript debugger
		);

		return $outputString;
	}
}

?>