<?php
	debug("Test");
?>