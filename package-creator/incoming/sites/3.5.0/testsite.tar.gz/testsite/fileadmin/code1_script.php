<?php


// Cache?:
// Typo3 caches pages by default. That means the content of your php-script is cached with everything else and thus your script is NOT executed next time you hit the page.
// Please notice that if you make a syntax error in your script, using set_no_cache() will NOT disable the page-cache and you must manually clear the cache from the backend and try again (after your script-bug is corrected that is... :-). Just keep it in mind...
// In order to disable caching, uncomment this line:


// set_no_cache();


if (is_object($this))	{

		// $this->data is the current record. Try to uncomment the line below and see!

//	debug($this->data);
	$params = $this->processParams($this->data["bodytext"]);
//	debug($params);

	$content.=$this->wrap("Content of 'code1' script, wrapped...",$params["wrap"]);

	
} else {
	die ("This script must be included by TypoScript");
}


?>
