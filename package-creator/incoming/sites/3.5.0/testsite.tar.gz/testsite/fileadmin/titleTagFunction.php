<?php

function user_pageTitle($content,$conf)	{
	// $content is the default title. Must return the title as value
	// $conf has no content, just empty array in this case.

	$content ="";	// resetting the default title to empty
	$parts=array();
	for ($a=0;$a<count($GLOBALS["TSFE"]->rootLine);$a++)	{
		$parts[]=htmlspecialchars($GLOBALS["TSFE"]->rootLine[$a]["title"]);
	}
	$content = implode(": ",$parts);
	
	return $content;
}


?>
