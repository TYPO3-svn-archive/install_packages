<?php
/*

 NOTICE ABOUT CONFIGURATION:
 
 Typo3 offers an install tool with three simple steps to configure the most necessary options such as the database.
 Please go to typo3/install/index.php to configure Typo3 and install the database tables.
 Just make sure this file is writable by PHP - otherwise the Install Tool will not succeed with the configuration.

 If you want to manually enter values into this file take a look at t3lib/config_default.php which is the file that includes this one. By looking into this file you should be able to figure out which variables set which values.
 
*/

$TYPO3_CONF_VARS["SYS"]["sitename"] = 'QuickStart';
$TYPO3_CONF_VARS["EXT"]["extList"] = 'tsconfig_help,context_help,extra_page_cm_options,rte,impexp,sys_note,tstemplate,tstemplate_ceditor,tstemplate_info,tstemplate_objbrowser,tstemplate_analyzer,tstemplate_styler,func_wizards,wizard_crpages,wizard_sortpages,lowlevel,install,belog,beuser,phpmyadmin,aboutmodules,imagelist,setup,taskcenter,sys_notepad,taskcenter_recent,taskcenter_rootlist,info_pagetsconfig,viewpage,tt_guest,mininews,tt_board,sys_todos,sys_workflows,conf_userts';       // Modified or inserted by Typo3 Extension Manager. 

// Setting Install Tool password to the default "joh316":
$TYPO3_CONF_VARS["BE"]["installToolPassword"] = "bacb98acf97e0b6112b1d1b650b84971";

?>