<?php
/**
 * Language labels for plugin "tx_mininews_pi1"
 * 
 * This file is detected by the translation tool.
 */

$LOCAL_LANG = Array (
	"default" => Array (
		"pi_list_browseresults_prev" => "< Previous",	
		"pi_list_browseresults_page" => "Page",	
		"pi_list_browseresults_next" => "Next >",	
		"pi_list_searchBox_search" => "Search",
		"pi_list_browseresults_displays" => "Displaying results ###SPAN_BEGIN###%s to %s</span> out of ###SPAN_BEGIN###%s</span>",
		"teaser_readMore" => "[more...]",
		"back" => "Back",
	),
	"dk" => Array (
		"teaser_readMore" => "[mere...]",
		"pi_list_browseresults_prev" => "< Forrige",	
		"pi_list_browseresults_page" => "Side",	
		"pi_list_browseresults_next" => "N�ste >",	
		"pi_list_searchBox_search" => "S�g",
		"pi_list_browseresults_displays" => "Viser resultaterne ###SPAN_BEGIN###%s til %s</span> ud af ###SPAN_BEGIN###%s</span>",
		"back" => "Tilbage",
	),
	"de" => Array (
	),
	"no" => Array (
	),
	"it" => Array (
	),
	"fr" => Array (
	),
	"es" => Array (
	),
	"nl" => Array (
	),
	"cz" => Array (
	),
	"pl" => Array (
	),
	"si" => Array (
	),
	"fi" => Array (
	),
	"tr" => Array (
	),
);
?>