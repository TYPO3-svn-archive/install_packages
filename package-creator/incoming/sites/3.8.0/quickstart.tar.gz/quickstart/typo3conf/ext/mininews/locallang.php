<?php
/**
 * Language labels for extension "mininews"
 * 
 * This file is detected by the translation tool.
 */

$LOCAL_LANG = Array (
	"default" => Array (
		"pi1_title" => "Mini news",	
		"pi1_plus_wiz_description" => "Mini news",	
	),
	"dk" => Array (
	),
	"de" => Array (
	),
	"no" => Array (
	),
	"it" => Array (
	),
	"fr" => Array (
	),
	"es" => Array (
	),
	"nl" => Array (
	),
	"cz" => Array (
	),
	"pl" => Array (
	),
	"si" => Array (
	),
	"fi" => Array (
	),
	"tr" => Array (
	),
);
?>