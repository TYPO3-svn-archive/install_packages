<?php
/**
 * "locallang" file - contains the labels and their translations for the modules content.
 * These kinds of files are translated on typo3.org with a special interface available for all the official translators of TYPO3.
 */

$LOCAL_LANG = Array (
	'default' => Array (	// Default english labels:
		'title' => 'Photo Marathon (EXAMPLE)',
		'menu' => 'Select a function',
		'menu_overview' => 'Overview of Photo Marathon records',
		'menu_list' => 'List Photo Marathon records on the page'
	),
	'dk' => Array (		// Danish labels:
		'title' => 'Foto Maraton (EKSEMPEL)',
		'menu' => 'V�lg en funktion',
		'menu_overview' => 'Overblik over foto maraton emner',
		'menu_list' => 'Liste over foto maraton emner p� siden'
	)
)
?>
