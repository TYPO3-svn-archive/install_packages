<?php

########################################################################
# Extension Manager/Repository config file for ext: 'user_set_page_title'
# 
# Auto generated 25-06-2002 16:33
# 
# Manual updates:
# Only the data in the array - anything else is removed by next write
########################################################################

$EM_CONF[$_EXTKEY] = Array (
	"title" => "Extending a system class",
	"description" => "Demonstrates how to write a simple extension class and configure it, so it gets included and used. In this case the page title shown in the browser title bar of frontend pages will be wrapped with ::",
	"category" => "example",
	"shy" => 0,
	"dependencies" => "",
	"priority" => "",
	"state" => "test",
	"internal" => 0,
	"clearCacheOnLoad" => 1,
	"author" => "Kasper Sk�rh�j",
	"author_email" => "kasper@typo3.com",
	"author_company" => "Curby Soft Multimedia",
	"_md5_values_when_last_written" => "a:2:{s:29:\"class.ux_t3lib_TStemplate.php\";s:4:\"7633\";s:17:\"ext_localconf.php\";s:4:\"1e03\";}",
	"version" => "0.0.0",	// Don't modify this! Managed automatically during upload to repository.
);

?>