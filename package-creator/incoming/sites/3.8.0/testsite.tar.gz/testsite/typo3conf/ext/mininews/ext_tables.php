<?php
if (!defined ("TYPO3_MODE")) 	die ("Access denied.");
$tempColumns = Array (
	"tx_mininews_frontpage_list" => Array (		
		"exclude" => 1,		
		"label" => "Listing mode:|",		
		"config" => Array (
			"type" => "select",
			"items" => Array (
				Array("Show archive/search|", "0"),
				Array("Frontpage teaser|", "1"),
			),
		)
	),
);


t3lib_div::loadTCA("tt_content");
t3lib_extMgm::addTCAcolumns("tt_content",$tempColumns,1);


t3lib_extMgm::allowTableOnStandardPages("tx_mininews_news");


t3lib_extMgm::addToInsertRecords("tx_mininews_news");

$TCA["tx_mininews_news"] = Array (
	"ctrl" => Array (
		"title" => "News|Nyheder",		
		"label" => "title",	
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"default_sortby" => "ORDER BY datetime DESC",	
		"delete" => "deleted",	
		"enablecolumns" => Array (		
			"disabled" => "hidden",	
			"starttime" => "starttime",	
			"endtime" => "endtime",	
			"fe_group" => "fe_group",
		),
		"dynamicConfigFile" => t3lib_extMgm::extPath($_EXTKEY)."tca.php",
		"iconfile" => t3lib_extMgm::extRelPath($_EXTKEY)."icon_tx_mininews_news.gif",
	),
	"feInterface" => Array (
		"fe_admin_fieldList" => "hidden, starttime, endtime, fe_group, datetime, title, teaser, full_text, front_page",
	)
);


t3lib_div::loadTCA("tt_content");
$TCA["tt_content"]["types"]["list"]["subtypes_excludelist"][$_EXTKEY."_pi1"]="layout,select_key";
$TCA["tt_content"]["types"]["list"]["subtypes_addlist"][$_EXTKEY."_pi1"]="tx_mininews_frontpage_list;;;;1-1-1";


t3lib_extMgm::addPlugin(Array("Mini news|", $_EXTKEY."_pi1"),"list_type");


if (TYPO3_MODE=="BE")	$TBE_MODULES_EXT["xMOD_db_new_content_el"]["addElClasses"]["tx_mininews_pi1_wizicon"] = t3lib_extMgm::extPath($_EXTKEY)."pi1/class.tx_mininews_pi1_wizicon.php";
?>