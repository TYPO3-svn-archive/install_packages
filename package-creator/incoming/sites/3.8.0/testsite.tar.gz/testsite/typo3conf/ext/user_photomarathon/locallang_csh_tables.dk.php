<?php
/**
 * "dk" TCA_DESCR for "fe_groups"
 */

$LOCAL_LANG['dk'] = Array (
	'description.description' => 'Beskrivelse af billedet',
	'image.description' => 'Brugerne kan uploade op til 2 billeder.',
	'photodate.description' => 'Datoen for fotografiet.',
	'fe_cruser_id.description' => 'Reference til brugeren, som ejer billedet.'
);
?>