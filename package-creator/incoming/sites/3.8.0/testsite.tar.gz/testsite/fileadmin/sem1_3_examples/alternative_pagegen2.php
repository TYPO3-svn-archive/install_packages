<?php

if (!is_object($TSFE))	{die('You cannot execute this file directly. It\'s meant to be included from index_ts.php');}


ob_start();
?>
This page has id #<?php echo $GLOBALS['TSFE']->id; ?>
<hr />DIRECT output here!
<?php
$GLOBALS['TSFE']->content = ob_get_contents(); 
ob_end_clean();
?>