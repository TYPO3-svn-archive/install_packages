<?php

class user_test_library_class {
	var $cObj;	// reference to the calling object.
	
	function test($content,$conf)	{
		global $TSFE;
		$TSFE->set_no_cache();	// Turning caching off - good while developing.
	
		$outputString = $this->cObj->cObjGetSingle(
			$conf['a_content_object'],	// Contains the name, here 'TEXT'
			$conf['a_content_object.'],	// Contains the properties of 'TEXT'
			'a_content_object'	// Basically just information for the TypoScript debugger
		);

		return $outputString;
	}
}

?>