<?php

class user_test_library_class {
	var $cObj;	// reference to the calling object.
	
	function test($content,$conf)	{
		global $TSFE;
		$TSFE->set_no_cache();
	
			//�Setting�the�output�string:
		$outputString = 'HELLO WORLD';
	
			// If set, add the font-tag parameters to this associative array:
		$fontTagParams = array();
		if ($conf['fontStyle.']['color']) $fontTagParams['color']=$conf['fontStyle.']['color'];
		if ($conf['fontStyle.']['face']) $fontTagParams['face']=$conf['fontStyle.']['face'];

			// If any font-tag parameters was set, wrap the output string:
		if (count($fontTagParams))	{
				// Compile array to attribute string
			$fontTagAttributes = t3lib_div::implodeParams($fontTagParams);	
			$outputString = '<font '.$fontTagAttributes.'>'.$outputString.'</font>';
		}
		
			// If border is enabled:
		if ($conf['border'])	{
			$outputString = 
				'<table border="1" bordercolor="'.
					($conf['border.']['color']?$conf['border.']['color']:'teal').
					'"><tr><td>'.
				$outputString.
				'</td></tr></table>';
		}
		return $outputString;
	}
}

?>