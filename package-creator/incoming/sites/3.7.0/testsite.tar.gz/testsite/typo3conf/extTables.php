<?php
/**
 * Extension script.
 *
 * You are strongly recommended to use the distributed tables.php file found in t3lib/install/tables.php. 
 * However extending and/or modifying the content of tables.php is done with scripts like this. 
 * Or BETTER yet - with extensions like those found in the typo3conf/ext/ or typo3/ext/ folder. 
 * Extensions are movable to other Typo3 installations and provides a much better division between things! Use them!
 *
 * Information on how to set up tables is found in the document "Inside Typo" available as a PDF from where you downloaded Typo3.
 */


/**
 * This adds an extra tt_content column (colPos=4), before the last column (Border):
 * The function array_splice works directly on the input array!
 */
t3lib_div::loadTCA('tt_content');	// Make sure the whole tt_content configuration is loaded, before we can modify it!
if (is_array($TCA['tt_content']))	{
	array_splice(
		$TCA['tt_content']['columns']['colPos']['config']['items'],		// The list of items
		-1,		// To insert one position from the end of the list
		0,		// Don't remove any items, just insert
		array(array('Extra Column|Ekstra kolonne',4))		// Element to be inserted. Value is '4' and language is specified for english and danish.
	);
}

?>