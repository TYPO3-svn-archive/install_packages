<?php
/**
 * "locallang" file - contains the labels and their translations for the module name and descriptions.
 * These kinds of files are translated on typo3.org with a special interface available for all the official translators of TYPO3.
 */

$LOCAL_LANG = Array (
	'default' => Array (
			// Short description for the tab image label:
		'mlang_labels_tablabel' => 'Photo Marathon (EXAMPLE!)',
			// Longer description, used in the 'Help>About modules' module 
		'mlang_labels_tabdescr' => 'This is an example module related to the Photo Marathon part of the testsite. It\'s made to provide you with a framework for creating your own backend modules. Please dive into the php-scripts in typo3conf/web/uphotomarathon/*',
		'mlang_tabs_tab' => 'Photo Marathon',
	),
	
		// Danish translation. This simply duplicates the key in the "default" array above, but with danish translations of the contents.
	'dk' => Array (
		'mlang_labels_tablabel' => 'Fotomaraton (Eksempelmodul)',
		'mlang_tabs_tab' => 'Fotomaraton',
	),
);
?>