<?php

	// Relative path to the module from the typo3/ folder
define('TYPO3_MOD_PATH','../typo3conf/ext/user_photomarathon/modsub/');		
	// Relative path to the typo3/ folder
$BACK_PATH='../../../../typo3/';					

	// Icon-file used with the module. Max 12 pixels high.
$MLANG['default']['tabs_images']['tab'] = 'tab_icon.gif';
	// Pointer to the file containing the descriptive labels for the module:
$MLANG['default']['ll_ref']='LLL:EXT:user_photomarathon/modsub/locallang_mod.php';


	// Main script invoked:
$MCONF['script']='index.php';		
	// Access level.
	// You can specify access for both backend users and groups to this module.
$MCONF['access']='user,group';		

	// Syntax: [module]_[subModule]  or just [module] if no submodule!! 
	// Remember, never use underscore '_' in module names!
$MCONF['name']='web_uphotomarathon';		

?>
