<?php
	debug('Test');
?>