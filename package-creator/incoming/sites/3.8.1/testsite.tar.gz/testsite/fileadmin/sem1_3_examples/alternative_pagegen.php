<?php

if (!is_object($TSFE))	{
	die('You cannot execute this file directly. It\'s meant to be included from index_ts.php');
}

$GLOBALS['TSFE']->content='This�page�has�id�#'.$GLOBALS['TSFE']->id;
echo�'DIRECT�output�here!<hr />';
?>