# MySQL dump 6.4
#
# Host: localhost    Database: t3_testsite
#--------------------------------------------------------
# Server version	3.22.27

#
# Table structure for table 'user_photomarathon'
#
CREATE TABLE user_photomarathon (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  fe_cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  images tinyblob NOT NULL,
  photodate int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Dumping data for table 'user_photomarathon'
#


