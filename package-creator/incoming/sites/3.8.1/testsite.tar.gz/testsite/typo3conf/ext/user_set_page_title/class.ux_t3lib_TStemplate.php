<?php

/**
 * Extension of the t3lib_TStemplate class.
 *
 * This is just a simple example. The method printTitle() in t3lib_TStemplate is overridden 
 * by this method. The parent class' function called so the correct title is set, BUT the title
 * is wrapped with '::' both left and right. Just an example of how to extend classes in Typo3.
 */
class ux_t3lib_TStemplate extends t3lib_TStemplate {
	function printTitle($title,$no_title=0)	{
		$title = parent::printTitle($title,$no_title);
		return '::'.$title.'::';
	}
}
?>