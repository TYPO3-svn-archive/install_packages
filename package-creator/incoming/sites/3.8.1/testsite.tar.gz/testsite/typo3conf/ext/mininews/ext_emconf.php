<?php

########################################################################
# Extension Manager/Repository config file for ext: 'mininews'
# 
# Auto generated 19-09-2002 01:17
# 
# Manual updates:
# Only the data in the array - anything else is removed by next write
########################################################################

$EM_CONF[$_EXTKEY] = Array (
	"title" => "Mini news",
	"description" => "A quite simple news module",
	"category" => "plugin",
	"shy" => 0,
	"dependencies" => "cms",
	"conflicts" => "",
	"priority" => "",
	"module" => "",
	"state" => "",
	"internal" => 0,
	"uploadfolder" => 0,
	"createDirs" => "uploads/tx_mininews/rte/",
	"modify_tables" => "tt_content",
	"clearCacheOnLoad" => 1,
	"lockType" => "",
	"author" => "Kasper Sk�rh�j",
	"author_email" => "kasper@typo3.com",
	"author_company" => "",
	"private" => 0,
	"download_password" => "",
	"version" => "0.0.11",	// Don't modify this! Managed automatically during upload to repository.
	"_md5_values_when_last_written" => "a:15:{s:12:\"ext_icon.gif\";s:4:\"1bdc\";s:17:\"ext_localconf.php\";s:4:\"3784\";s:14:\"ext_tables.php\";s:4:\"67af\";s:14:\"ext_tables.sql\";s:4:\"c51a\";s:28:\"ext_typoscript_editorcfg.txt\";s:4:\"07ec\";s:25:\"icon_tx_mininews_news.gif\";s:4:\"1e24\";s:13:\"locallang.php\";s:4:\"be06\";s:7:\"tca.php\";s:4:\"f634\";s:14:\"pi1/ce_wiz.gif\";s:4:\"02b6\";s:29:\"pi1/class.tx_mininews_pi1.php\";s:4:\"6bc1\";s:37:\"pi1/class.tx_mininews_pi1_wizicon.php\";s:4:\"65b7\";s:13:\"pi1/clear.gif\";s:4:\"cc11\";s:17:\"pi1/locallang.php\";s:4:\"ecac\";s:19:\"doc/wizard_form.dat\";s:4:\"bb63\";s:20:\"doc/wizard_form.html\";s:4:\"9587\";}",
);

?>