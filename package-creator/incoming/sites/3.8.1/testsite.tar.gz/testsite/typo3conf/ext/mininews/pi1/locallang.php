<?php
/**
 * Language labels for plugin "tx_mininews_pi1"
 * 
 * This file is detected by the translation tool.
 */

$LOCAL_LANG = Array (
	"default" => Array (
		"listFieldHeader_datetime" => "Time / Date:",	
		"listFieldHeader_title" => "Title:",	
		"listFieldHeader_teaser" => "Teaser text:",	
		"listFieldHeader_full_text" => "Full story:",	
		"listFieldHeader_front_page" => "Show on front page?",	
		"list_mode_1" => "Mode 1",	
		"list_mode_2" => "Mode 2",	
		"list_mode_3" => "Mode 3",	
		"pi_list_browseresults_prev" => "< Previous",	
		"pi_list_browseresults_page" => "Page",	
		"pi_list_browseresults_next" => "Next >",	
	),
	"dk" => Array (
	),
	"de" => Array (
	),
	"no" => Array (
	),
	"it" => Array (
	),
	"fr" => Array (
	),
	"es" => Array (
	),
	"nl" => Array (
	),
	"cz" => Array (
	),
	"pl" => Array (
	),
	"si" => Array (
	),
	"fi" => Array (
	),
	"tr" => Array (
	),
);
?>