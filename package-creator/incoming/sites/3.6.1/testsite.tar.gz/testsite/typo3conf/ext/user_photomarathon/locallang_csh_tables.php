<?php
/**
 * Default  TCA_DESCR for "fe_groups"
 */

$LOCAL_LANG = Array (
	'default' => Array (
		'title.description' => 'Enter the title of the image.',
		'title.details' => 'This is displayed in the headers on the webpages.',
		'_title.seeAlso' => 'user_photomarathon:description,user_photomarathon:images',
		'description.description' => 'Users may enter a description. This is shown with the image.',
		'image.description' => 'The image. Users may upload up to 2 images.',
		'photodate.description' => 'The date of the photo',
		'fe_cruser_id.description' => 'This field contains a reference to the fe_user (website user) who owns it. You should not change this. If you remove the user, the image will no longer belong to him and he cannot edit the image. In addition if you simply insert another user, the image will belong to this new user from that point in time.'
	),
	'dk' => 'EXT'
);
?>