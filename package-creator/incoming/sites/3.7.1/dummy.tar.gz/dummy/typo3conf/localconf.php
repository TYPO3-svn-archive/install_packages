<?php
$TYPO3_CONF_VARS["SYS"]["sitename"] = "Blank DUMMY";
	// Default password is "joh316" :
$TYPO3_CONF_VARS["BE"]["installToolPassword"] = "bacb98acf97e0b6112b1d1b650b84971";
?>