<?php

$LOCAL_LANG = Array (
	'default' => Array (
		'table_title' => 'Photo Marathon image',
		'title' => 'Image title:',
		'label' => 'Image description:',
		'photodate' => 'Date:',
		'fe_cruser_id' => 'Front End Owner:',
		'image' => 'Image',
		'hidden' => 'Hidden',
	),	
	'dk' => Array (
		'table_title' => 'Photo Maraton Billede',
		'title' => 'Billedtitel:',
		'label' => 'Billedbeskrivelse:',
		'photodate' => 'Dato:',
		'fe_cruser_id' => 'Website-bruger ejer:',
	),	
	'de' => Array (
		'table_title' => 'Photo Marathon Bild',
		'title' => 'Bildtitel:',
		'label' => 'Bildbeschreibung:',
		'photodate' => 'Datum:',
		'fe_cruser_id' => 'Frontend Besitzer:',
	),	
);
?>