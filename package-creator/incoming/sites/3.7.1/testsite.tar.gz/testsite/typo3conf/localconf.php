<?php
$TYPO3_CONF_VARS['SYS']['sitename'] = 'TYPO3 Testsite';
	// Default password is 'joh316' :
$TYPO3_CONF_VARS['BE']['installToolPassword'] = 'bacb98acf97e0b6112b1d1b650b84971';
$TYPO3_CONF_VARS['FE']['logfile_dir'] = 'fileadmin/';
$typo_db_extTableDef_script = 'extTables.php';

$TYPO3_CONF_VARS['BE']['defaultUserTSconfig']='
';
$TYPO3_CONF_VARS['BE']['defaultPageTSconfig']='
	TCEFORM.pages.TSconfig.linkTitleToSelf=1
';
#$TYPO3_CONF_VARS['BE']['forceCharset']='utf-8';


$TYPO3_CONF_VARS['EXT']['requiredExt'] = 'cms,lang';
$TYPO3_CONF_VARS['EXT']['extList'] = 'css_styled_content,tsconfig_help,context_help,extra_page_cm_options,sys_note,tstemplate,tstemplate_ceditor,tstemplate_info,tstemplate_objbrowser,tstemplate_analyzer,func_wizards,wizard_crpages,wizard_sortpages,lowlevel,install,belog,beuser,phpmyadmin,aboutmodules,imagelist,setup,taskcenter,sys_notepad,taskcenter_recent,taskcenter_rootlist,info_pagetsconfig,metatags,tt_address,tt_calender,direct_mail_subscription,feuser_admin,tt_guest,tt_board,tt_news,tt_poll,tt_rating,tipafriend,plugin_mgm,taskcenter_modules,sys_action,sys_todos,sys_workflows,user_photomarathon,static_file_edit,sys_stat,viewpage,tt_products,direct_mail,extrep_wizard,indexed_search,tstemplate_styler,mininews,user_set_page_title,impexp,rte,rte_conf';
$TYPO3_CONF_VARS['EXT']['allowGlobalInstall'] = '1';
$TYPO3_CONF_VARS['EXT']['extConf']['css_styled_content'] = 'a:1:{s:15:"setPageTSconfig";s:1:"0";}';
$TYPO3_CONF_VARS['EXT']['extConf']['indexed_search'] = 'a:3:{s:8:"pdftools";s:0:"";s:6:"catdoc";s:0:"";s:8:"pdf_mode";s:3:"-20";}';

## INSTALL SCRIPT EDIT POINT TOKEN - all lines after this points may be changed by the install script!

$typo_db_username = '';
$typo_db_password = '';
$typo_db_host = '';
$typo_db = '';

?>