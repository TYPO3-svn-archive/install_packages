<?php
/**
 * Language labels for extension "mininews", database tables.
 * 
 * This file is detected by the translation tool.
 */

$LOCAL_LANG = Array (
	"default" => Array (
		"tt_content.list_type" => "Mini news",
		"tt_content.tx_mininews_frontpage_list" => "Listing mode:",
		"tt_content.tx_mininews_frontpage_list.I.0" => "Show archive/search",
		"tt_content.tx_mininews_frontpage_list.I.1" => "Frontpage teaser",
		"tx_mininews_news" => "News",
		"tx_mininews_news.datetime" => "Time / Date:",
		"tx_mininews_news.title" => "Title:",
		"tx_mininews_news.teaser" => "Teaser text:",
		"tx_mininews_news.full_text" => "Full story:",
		"tx_mininews_news.full_text.W.RTE" => "Full screen Rich Text Editing",
		"tx_mininews_news.front_page" => "Show on front page?",
	),
	"dk" => Array (
		"tt_content.list_type" => "Mini nyheder",
		"tt_content.tx_mininews_frontpage_list" => "Visningstype:",
		"tt_content.tx_mininews_frontpage_list.I.0" => "Vis arkiv/s�gning",
		"tt_content.tx_mininews_frontpage_list.I.1" => "Forside teaser",
		"tx_mininews_news" => "Nyheder",
		"tx_mininews_news.datetime" => "Tid / Dato:",
		"tx_mininews_news.title" => "Titel:",
		"tx_mininews_news.teaser" => "Manchet tekst:",
		"tx_mininews_news.full_text" => "Fuld historie:",
		"tx_mininews_news.full_text.W.RTE" => "Formatteret redigering i hele vinduet",
		"tx_mininews_news.front_page" => "Vis p� forsiden?",
	),
	"de" => Array (
	),
	"no" => Array (
	),
	"it" => Array (
	),
	"fr" => Array (
	),
	"es" => Array (
	),
	"nl" => Array (
	),
	"cz" => Array (
	),
	"pl" => Array (
	),
	"si" => Array (
	),
	"fi" => Array (
	),
	"tr" => Array (
	),
);
?>